## How to run
### Task 1
1. cd SDQP
2. mkdir build && cd build 
3. cmake.. && make
4. ./sdqp_example

### Task 2
1. cd SOCP
2. mkdir build && cd build 
3. cmake.. && make
4. ./socp_example